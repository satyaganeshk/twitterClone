const express = require('express')
const {open} = require('sqlite')
const sqlite3 = require('sqlite3')
const path = require('path')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')

const dbPath = path.join(__dirname, 'twitterClone.db')
const app = express()
app.use(express.json())
let db = null
const intializeDatabase = async () => {
  try {
    db = await open({
      filename: dbPath,
      driver: sqlite3.Database,
    })
    app.listen(3000, () => console.log('Sever is Running'))
  } catch (e) {
    console.log(`DB Error ${e.message}`)
    process.exit(1)
  }
}

intializeDatabase()
function authenticateToken(request, response, next) {
  let jwtToken
  const authHeader = request.headers['authorization']
  if (authHeader !== undefined) {
    jwtToken = authHeader.split(' ')[1]
  }
  if (jwtToken === undefined) {
    response.status(401)
    response.send('Invalid JWT Token')
  } else {
    jwt.verify(jwtToken, 'MY_SECRET_TOKEN', async (error, payload) => {
      if (error) {
        response.status(401)
        response.send('Invalid JWT Token')
      } else {
        next()
      }
    })
  }
}

app.post('/register/', async (request, response) => {
  const {username, password, name, gender} = request.body
  const hashedPassword = await bcrypt.hash(password, 10)
  const selectUser = `SELECT * FROM user WHERE username = '${username}';`
  const isUserExist = await db.get(selectUser)
  console.log(isUserExist)
  if (isUserExist === undefined) {
    if (password.length >= 6) {
      const createUserQuery = `
        INSERT INTO
            user(username, password, name, gender)
        VALUES(
          '${username}',
          '${hashedPassword}',
          '${name}',
          '${gender}'
        );
    `
      await db.run(createUserQuery)
      response.send('User created successfully')
    } else if (password.length < 6) {
      response.status(400)
      response.send('Password is too short')
    }
  } else {
    response.status(400)
    response.send('User already exists')
  }
})

app.post('/login', async (request, response) => {
  const {username, password} = request.body
  const selectUser = `SELECT * FROM user WHERE username = '${username}';`
  const dbUser = await db.get(selectUser)
  if (dbUser === undefined) {
    response.status(400)
    response.send('Invalid user')
  } else {
    const isPasswordMatched = await bcrypt.compare(password, dbUser.password)
    if (isPasswordMatched === true) {
      const payload = {
        username: username,
      }
      const jwtToken = jwt.sign(payload, 'MY_SECRET_TOKEN')
      response.send({jwtToken})
    } else {
      response.status(400)
      response.send('Invalid password')
    }
  }
})
app.get('/user/tweets/feed/', authenticateToken, async (req, res) => {
  const {userId} = req.user.user_id
  const {userName} = req.user.username
  try {
    // Fetch user_id for the authenticated user
    const userQuery = `SELECT user_id FROM user WHERE username = '${userName}'`
    const user = await db.get(userQuery)

    if (!user) {
      return res.status(400).send('User not found')
    }

    const getTweetsQuery = `
      SELECT user.username, tweet.tweet, tweet.date_time AS dateTime
      FROM tweet
      INNER JOIN follower ON tweet.user_id = follower.following_user_id
      INNER JOIN user ON tweet.user_id = user.user_id
      WHERE follower.follower_user_id = ${user.user_id}
      ORDER BY tweet.date_time DESC
      LIMIT 4;
    `

    const tweets = await db.all(getTweetsQuery)
    res.send(tweets)
  } catch (error) {
    console.error(`Error fetching tweets: ${error.message}`)
    res.status(500).send('Internal Server Error')
  }
})

app.get('/user/following/', authenticateToken, async (req, res) => {
  const getFollowingQuery = `
    SELECT user.name
    FROM user
    INNER JOIN follower ON user.user_id = follower.following_user_id
    WHERE follower.follower_user_id = (SELECT user_id FROM user WHERE username = ?);
  `
  const following = await db.all(getFollowingQuery, [req.user.username])
  res.send(following)
})
app.get('/user/followers/', authenticateToken, async (req, res) => {
  const getFollowersQuery = `
    SELECT user.name
    FROM user
    INNER JOIN follower ON user.user_id = follower.follower_user_id
    WHERE follower.following_user_id = (SELECT user_id FROM user WHERE username = ?);
  `
  const followers = await db.all(getFollowersQuery, [req.user.username])
  res.send(followers)
})

app.get('/tweets/:tweetId/', authenticateToken, async (req, res) => {
  const {tweetId} = req.params
  const tweetQuery = `
    SELECT tweet, COUNT(DISTINCT like.like_id) AS likes, COUNT(DISTINCT reply.reply_id) AS replies, tweet.date_time as dateTime
    FROM tweet
    LEFT JOIN like ON tweet.tweet_id = like.tweet_id
    LEFT JOIN reply ON tweet.tweet_id = reply.tweet_id
    WHERE tweet.tweet_id = ? AND tweet.user_id IN (
      SELECT following_user_id FROM follower WHERE follower_user_id = (SELECT user_id FROM user WHERE username = ?)
    );
  `
  const tweet = await db.get(tweetQuery, [tweetId, req.user.username])

  if (!tweet) {
    res.status(401).send('Invalid Request')
  } else {
    res.send(tweet)
  }
})

module.exports = app
